package com.rafael.proffy.ui.login

import android.content.Intent
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.rafael.proffy.R
import com.rafael.proffy.databinding.ActivityLoginBinding
import com.rafael.proffy.ui.forgot.ForgotActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        enableEdgeToEdge()
        window.statusBarColor = ContextCompat.getColor(this, R.color.purple)

        binding.buttonForgot.setOnClickListener {
            handleForgot()
        }
    }

    private fun handleForgot() {
        val intent = Intent(this, ForgotActivity::class.java)
        startActivity(intent)
    }
}
