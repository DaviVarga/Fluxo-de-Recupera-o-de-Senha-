package com.rafael.proffy.ui.forgot

import android.content.Intent
import android.content.res.ColorStateList
import android.os.Bundle
import android.util.Patterns
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.doAfterTextChanged
import com.rafael.proffy.FinallyActivity
import com.rafael.proffy.R
import com.rafael.proffy.databinding.ActivityForgotBinding

class ForgotActivity : AppCompatActivity() {

    private lateinit var binding: ActivityForgotBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityForgotBinding.inflate(layoutInflater)
        setContentView(binding.root)

        enableEdgeToEdge()
        window.statusBarColor = ContextCompat.getColor(this, R.color.purple)
        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { view, insets ->
            val bars = insets.getInsets(
                WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime()
            )
            view.setPadding(bars.left, 0, bars.right, bars.bottom)
            insets
        }

        setButtonState(false)
        setupListeners()
    }

    private fun setupListeners() {
        binding.buttonGoBack.setOnClickListener {
            goBack()
        }

        binding.textInputEditEmail.doAfterTextChanged {
            validateEmail(showEmptyError = false)
        }

        binding.textInputEditEmail.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                validateEmail(showEmptyError = true)
            }
        }

        binding.buttonSendEmail.setOnClickListener {
            openFinally()
        }
    }

    private fun goBack() {
        finish()
    }

    private fun openFinally() {
        val intent = Intent(this, FinallyActivity::class.java)
        startActivity(intent)
    }

    private fun currentEmail(): String {
        return binding.textInputEditEmail.text?.toString()?.trim() ?: ""
    }

    private fun isValidEmail(email: String): Boolean {
        return email.isNotEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches()
    }

    private fun validateEmail(showEmptyError: Boolean) {
        val email = currentEmail()
        val isValid = isValidEmail(email)

        val errorRes = when {
            isValid -> null
            email.isEmpty() -> if (showEmptyError) R.string.forgot_error_empty else null
            else -> R.string.forgot_error_invalid
        }

        binding.textInputLayoutEmail.error = errorRes?.let { getString(it) }
        setButtonState(isValid)
    }

    private fun setButtonState(enabled: Boolean) {
        val button = binding.buttonSendEmail
        button.isEnabled = enabled

        val backgroundColor = ContextCompat.getColor(
            this,
            if (enabled) R.color.green else R.color.shape_disable
        )
        button.backgroundTintList = ColorStateList.valueOf(backgroundColor)

        val textColor = ContextCompat.getColor(
            this,
            if (enabled) R.color.shape_01_white else R.color.text_complement
        )
        button.setTextColor(textColor)

        button.setText(
            if (enabled) R.string.forgot_button_enabled else R.string.forgot_button_disabled
        )
    }
}
