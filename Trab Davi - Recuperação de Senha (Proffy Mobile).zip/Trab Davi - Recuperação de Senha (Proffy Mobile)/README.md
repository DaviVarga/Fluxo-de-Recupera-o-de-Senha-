# Proffy – Recuperação de Senha

- **Nome completo:** DAVI LUCAS VARGAS SOUZA
- **Turma:** 6º Período – Sistemas de Informação

## Implementação

A `ForgotActivity` valida o e-mail em tempo real com `doAfterTextChanged` e também ao sair do campo
(`setOnFocusChangeListener`), usando `Patterns.EMAIL_ADDRESS` após `trim()`. E-mail inválido mostra o erro no
`TextInputLayout` (texto em `strings.xml`); e-mail válido remove o erro, deixa o botão verde com o texto "Enviar" e
habilita o clique. Vazio ou inválido mantém o botão cinza, desabilitado, com o texto "Entrar".

Ao tocar em "Enviar", uma Intent explícita abre a `FinallyActivity`, cujo botão "Voltar ao login" retorna à
`LoginActivity` limpando a pilha de navegação (`FLAG_ACTIVITY_NEW_TASK | FLAG_ACTIVITY_CLEAR_TASK`).
